#include<lpc21xx.h>
#include<string.h>

void lcd_init(void);
void lcd_command(unsigned char);
void lcd_data(unsigned char);
void lcd_int(int);
void lcd_str(unsigned char *);
void delay_ms(unsigned char);
void delay_s(unsigned char);
void gsm1_code(void);
void gsm2_code(void);

void uart0_init(void);
void uart1_init(void);
unsigned char uart0_rx(void);
void uart0_tx(unsigned char);
unsigned char uart1_rx(void);
void uart1_tx(unsigned char);
void uart0_str(unsigned char *);
void uart1_str(unsigned char *);
unsigned int keyscan(void);

#define	c0 (IOPIN1&(1<<23))
#define	c1 (IOPIN1&(1<<24))
#define	c2 (IOPIN1&(1<<25))
#define	c3 (IOPIN1&(1<<26))
#define	r0 (1<<27)
#define	r1 (1<<28)
#define	r2 (1<<29)
#define	r3 (1<<30)




#define lcd 0xff<<10
#define RS 1<<6
#define E 1<<7

int main()
{
	int i,k,count=0;
	char key[10],pass[]="1111";
	unsigned char ch[20];
	char s[]="0600676AC2C9";
	k=0;
	IODIR0|=(1<<4)|(1<<5);
	IOCLR0=(1<<4)|(1<<5);
 	uart0_init();
    uart1_init();
	lcd_init();
	lcd_command(0x80); 
	lcd_str("welcome");
	delay_s(3);
	lcd_command(0x0c);
	while(1)
	{
		lcd_command(0x80);
		lcd_str("State Bank India");
		for(i=0;i<12;i++)
		{
			 ch[i]=uart0_rx();
		}
		if(i==12)
		ch[i]='\0';
		uart0_str(ch); 
		
		if(strcmp(s,ch)==0)
		{
			lcd_command(0xc0);
			lcd_str("Access Verified ");
			delay_s(5);
			LABEL:
			lcd_command(0xc0);
			lcd_str(" Enter pin:     ");
			lcd_command(0xcb);
			delay_s(5);
			while(k<4)
			{
				key[k++]= keyscan();
				delay_ms(200);
				lcd_str("*");
			}
				key[k]='\0'	;

				if(strcmp(pass,key)==0)
				{
					lcd_command(0xc0);
					lcd_str("PIN is verified ");
					delay_s(10);
					lcd_command(0xc0);
					lcd_str(" Locker opening ");
					IOSET0=(1<<4);
					IOCLR0=(1<<5);
					delay_s(10);
					IOCLR0=(1<<4)|(1<<5);
					delay_s(5);
					lcd_command(0xc0);
					lcd_str(" Locker closing ");
					IOCLR0=(1<<4);
					IOSET0=(1<<5);
					delay_s(10);
					IOCLR0=(1<<4)|(1<<5);
					lcd_command(0xc0);
					lcd_str("   Thank you    ");
					delay_s(5);
			
		  	  }
			else
			{
				count++;
				lcd_command(0xc0);
				lcd_str("  PIN is wrong  ");
				delay_s(5);
				lcd_command(0xc0);
				lcd_int(3-count);
				lcd_str("Attempts remains");
				delay_s(5);
				k=0;
				if(count<3)
				goto LABEL;
				else
				{
					lcd_command(0xc0);
					lcd_str("3 attemps over  ");
					delay_s(2);
					gsm2_code();
				}
			}
		}
		else 
		{
			lcd_command(0xc0);
			lcd_str("Un Authorised Access...");
			delay_s(5);
			gsm1_code();
		}
			
	}	
}

 
void gsm1_code(void)
{
		 uart1_str("AT\r\n");
		 delay_ms(200);
		 uart1_str("AT+CMGF=1\r\n");
		 delay_ms(200);
		 uart1_str("AT+CMGS=\"+919597572128\"\r\n");
		 delay_ms(200);
		 uart1_str("Undefined rfid access on locker-***  \r\n");
		 delay_ms(200);
		 uart1_tx(0x1A);
		 delay_s(2);

}

void gsm2_code(void)
{
		 uart1_str("AT\r\n");
		 delay_ms(200);
		 uart1_str("AT+CMGF=1\r\n");
		 delay_ms(200);
		 uart1_str("AT+CMGS=\"+919597572128\"\r\n");
		 delay_ms(200);
		 uart1_str("Wrong Pin Entry ... more than 3 attempts\r\n");
		 delay_ms(200);
		 uart1_tx(0x1A);
		 delay_s(2);

}

  

void uart0_init(void)
{
	PINSEL0=0X5;
	U0LCR=0X83;
	U0DLL=97;
	U0DLM=0;
	U0LCR=0X03;
}
void uart0_tx(unsigned char tx_byte)
{
	while(((U0LSR>>5)&1)==0);
	U0THR=tx_byte;
}
unsigned char uart0_rx(void)
{
	while((U0LSR&1)==0);
	return U0RBR;
}
void uart0_str(unsigned char *p)
{
while(*p)
{
	while(((U0LSR>>5)&1)==0);
	U0THR=*p++;
}
}


void uart1_init(void)
{
	PINSEL0|=(1<<16)|(1<<18);
	U1LCR=0X83;
	U1DLL=8;
	U1DLM=0;
	U1LCR=0X03;
}
void uart1_tx(unsigned char tx_byte)
{
	while(((U1LSR>>5)&1)==0);
	U1THR=tx_byte;
}
unsigned char uart1_rx(void)
{
	while((U1LSR&1)==0);
	return U1RBR;
}
void uart1_str(unsigned char *p)
{
while(*p)
{
	while(((U1LSR>>5)&1)==0);
	U1THR=*p++;
}
}		  

void lcd_init(void)
{
	IODIR0|=lcd|RS|E;
	lcd_command(0x01);
	lcd_command(0x02);
	lcd_command(0x0c);
	lcd_command(0x38);
}

void lcd_command(unsigned char c)
{
	IOCLR0=lcd;
	IOSET0=c<<10;
	IOCLR0=RS;
	IOSET0=E;
	delay_ms(2);
	IOCLR0=E;
}

void lcd_data(unsigned char d)
{
	IOCLR0=lcd;
	IOSET0=d<<10;
	IOSET0=RS;
	IOSET0=E;
	delay_ms(2);
	IOCLR0=E;
}


void lcd_int(int n)
{
	int i=0;
	char arr[5];
	if(n==0)
	lcd_data('0');
	else
	{
		if(n<0)
		{
			lcd_data('-');
			n=-n;
			}
		while(n>0)
		{
			arr[i++]=n%10;
			n=n/10;
		}
		for(--i;i>=0;i--)
		lcd_data(arr[i]+48);
	}
}

void lcd_str(unsigned char *s)
{
	while(*s)
	lcd_data(*s++);
}

void delay_ms(unsigned char n)
{
	T0PR=15000-1;
	T0TCR=0x01;
	while(T0TC<n);
	T0TCR=0x03;
	T0TCR=0x00;
}
void delay_s(unsigned char n)
{
	T0PR=15000000-1;
	T0TCR=0x01;
	while(T0TC<n);
	T0TCR=0x03;
	T0TCR=0x00;
}

unsigned int keyscan(void)
{
unsigned int k[4][4]={{'1','2','3',' '},{'4','5','6',' '},{'7','8','9',' '},{' ',0,' ',' '}};
	unsigned char row=0,col=0;
	IODIR1=r0|r1|r2|r3;
	while(1)
	{
		IOCLR1=r0|r1|r2|r3;
		IOSET1=c0|c1|c2|c3;
		while((c0&&c1&&c2&&c3)==1);
		IOCLR1=r0;
		IOSET1=r1|r2|r3;
		if((c0&&c1&&c2&&c3)==0)
		{
			row=0;
			break;
		}
		IOCLR1=r1;
		IOSET1=r0|r2|r3;
		if((c0&&c1&&c2&&c3)==0)
		{
			row=1;
			break;
		}
		IOCLR1=r2;
		IOSET1=r0|r1|r3;
		if((c0&&c1&&c2&&c3)==0)
		{
			row=2;
			break;
		}	
		IOCLR1=r3;
		IOSET1=r0|r1|r2;
		if((c0&&c1&&c2&&c3)==0)
		{
			row=3;
			break;
		}	
	}

	if(c0==0)
	col=0;
	else if(c1==0)
	col=1;
	else if(c2==0)
	col=2;
	else
	col=3;
	delay_ms(200);
	while((c0&&c1&&c2&&c3)==0);
	return k[row][col];
}




